package cn.xh.domain;

import java.util.List;

/**
 * @author lcl0411
 *
 * @param <T>
 * ��ҳ��
 */
public class Page<T> {
    private int totalCount; //��������
    private int pageSize;   //ҳ���С
    private int totalPageCount;  //ҳ������
    private int currentPage;  //��ǰҳ��
    private List<T> datas;
    
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
		if(this.pageSize  == 0) {
			return;
		}
		//����ҳ������
		this.totalPageCount = this.totalCount % this.pageSize == 0 ?
				(this.totalCount / this.pageSize) : ((this.totalCount / this.pageSize)+1);
	}
	
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
		if(this.totalCount == 0 ) {
			return;
		}
		//����ҳ������
		this.totalPageCount = this.totalCount % this.pageSize == 0 ?
						(this.totalCount / this.pageSize) : ((this.totalCount / this.pageSize)+1);
		
	}
	
	
	public int getTotalPageCount() {
		return totalPageCount;
	}

	
	
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	
	public List<T> getDatas() {
		return datas;
	}
	
	public void setDatas(List<T> datas) {
		this.datas = datas;
	}
    
    
    
}
