package cn.xh.web.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.xh.domain.Book;
import cn.xh.domain.Order;
import cn.xh.domain.Orderitem;
import cn.xh.domain.User;
import cn.xh.service.ClientService;
import cn.xh.service.ManagerService;
import cn.xh.service.OrderService;
import cn.xh.service.impl.ClientServiceImpl;
import cn.xh.service.impl.ManagerServiceImpl;
import cn.xh.service.impl.OrderServiceImpl;
import cn.xh.web.formbean.Cart;
import cn.xh.web.formbean.CartItem;

@WebServlet("/order/OrderServlet")
public class OrderServlet extends HttpServlet {
	private OrderService orderService = new OrderServiceImpl();
	private ManagerService managerService = new ManagerServiceImpl();
	private ClientService clientService = new ClientServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");
		String op = req.getParameter("op");// �õ�������������
		// ���ɶ���
		if (op.equals("genOrder")) {
			genOrder(req, resp);
		}
		if(op.equals("buyNow")){
			buyNow(req,resp);
		}
		if (op.equals("deleteOrder")){
			deleteOrder(req,resp);
		}
		if(op.equals("findOrderByUser")){
			findOrderByUser(req,resp);
		}
		// �鿴����
		if (op.equals("findAllOrders")) {
			findAllOrders(req, resp);
		}
		// ����Ա�鿴����
		if (op.equals("findOrders")) {
			findOrders(req, resp);
		}
		// ����
		if (op.equals("faHuo")) {
			faHuo(req, resp);
		}
	}

	private void buyNow(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		Cart cart = (Cart) session.getAttribute("buyNowBook");
		String booknums = req.getParameter("booknums");
		String bookmoneys = req.getParameter("bookmoneys");
		String bookmoney = bookmoneys.substring(1,bookmoneys.length());
		Order order = new Order();//�����ܶ���
		order.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));//����ʱ��
		String ordernum = genOrdernum();
		order.setOrdernum(ordernum);//�������
		order.setUser(user);
		order.setQuantity(Integer.parseInt(booknums));
		order.setMoney(Integer.parseInt(bookmoney));
		List<Orderitem> oItems = new ArrayList<Orderitem>();
		for (Map.Entry<String, CartItem> me : cart.getItmes().entrySet()) {//ѭ��ÿһ�����
			CartItem cItem = me.getValue();//�õ�map��valueֵ��Ҳ����ÿһ��������
			Orderitem oItem = new Orderitem();
			oItem.setId(genOrdernum());
			oItem.setBook(cItem.getBook());//�����������ŵ���book����
			oItem.setPrice(Double.parseDouble(bookmoney));
			oItem.setQuantity(Integer.parseInt(booknums));
			oItem.setOrdernum(ordernum);//��ȡ�ܶ���id��
			oItems.add(oItem);
		}
		order.setItems(oItems);

		orderService.genOrder(order);
		session.removeAttribute("buyNowBook");
		req.setAttribute("order", order);
		req.getRequestDispatcher("/order.jsp").forward(req, resp);
	}

	private void faHuo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String ordernum = req.getParameter("ordernum");
		orderService.faHuo(ordernum);
		List<Order> orders = orderService.findOrders();
		HttpSession session = req.getSession();
		session.setAttribute("orders", orders);
		//System.out.println(orders);
		resp.sendRedirect(req.getContextPath() + "/admin/managerOrder.jsp");
	}
//ɾ���ܶ���
	private void deleteOrder(HttpServletRequest req, HttpServletResponse resp) throws IOException {//ɾ��������֮ǰ�Ȼָ�ͼ���棬��ɾ���ܶ���
		String ordernum = req.getParameter("ordernum");
		String status = req.getParameter("status");
		if (status.equals("1")){
			List<Orderitem> items = findOrderItems(ordernum);//����ܶ�����������ж�����
			for (Orderitem item : items) {
				Book book = managerService.findBookById(item.getBook().getBook_id());
				int i = book.getBook_kunumber();//���п��
				String kunnumber = String.valueOf(i+item.getQuantity());//���п����϶�����������������ָ�ͼ��Ŀ��
				managerService.editBook(item.getBook().getBook_id(),item.getBook().getBook_name(),item.getBook().getBook_author(),item.getBook().getBook_press(),item.getBook().getBook_desc(),item.getBook().getBook_price(),kunnumber);
				orderService.deleteOrderitems(item.getId());//ɾ��������
			}
			if(orderService.deleteOrder(ordernum)){
				resp.getWriter().write("<div style='text-align: center;margin-top: 260px'><img src='" + req.getContextPath()
						+ "/img/duigou.png'/>ɾ���ɹ���</div>");
			}else {
				resp.getWriter().write("<div style='text-align: center;margin-top: 260px'>����ɾ��ʧ�ܣ�</div>");
			}
		}else{
			resp.getWriter().write("<div style='text-align: center;margin-top: 260px'>����δ������</div>");
		}
	}
	private List<Orderitem> findOrderItems(String ordernum){
		return orderService.finOrdersItemsByNum(ordernum);
	}
	private void findOrders(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<Order> orders = orderService.findOrders();
		HttpSession session = req.getSession();
		session.setAttribute("orders", orders);
		req.getRequestDispatcher("/admin/managerOrder.jsp").forward(req, resp);
	}
	private void findOrderByUser(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("search");
		User users = clientService.selectUserByName(username);
		List<Order> userOrders = orderService.findUserOrders(users);
		req.setAttribute("orders", userOrders);
		req.getRequestDispatcher("/admin/managerOrder.jsp").forward(req, resp);
	}
	private void findAllOrders(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		List<Order> orders = orderService.findUserOrders(user);
		req.setAttribute("orders", orders);
		req.getRequestDispatcher("/person/personOrder.jsp").forward(req, resp);
	}

	private void genOrder(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		// ȡ�����ﳵ��Ϣ
		// ȡ����������Ϣ
		HttpSession session = req.getSession();
		Cart cart = (Cart) session.getAttribute("cart");
		User user = (User) session.getAttribute("user");
		if (cart == null) {
			resp.getWriter().write("�Ự�Ѿ���������");
			return;
		}
		Order order = new Order();
		order.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		String ordernum = genOrdernum();
		order.setOrdernum(ordernum);
		order.setQuantity(cart.getTotalQuantity());
		order.setMoney(cart.getTotalMoney());
		order.setUser(user);
		// ������
		List<Orderitem> oItems = new ArrayList<Orderitem>();
		for (Map.Entry<String, CartItem> me : cart.getItmes().entrySet()) {//ѭ��ÿһ�����
			CartItem cItem = me.getValue();//�õ�map��valueֵ��Ҳ����ÿһ��������
			Orderitem oItem = new Orderitem();
			oItem.setId(genOrdernum());
			oItem.setBook(cItem.getBook());//�����������ŵ���book����
			oItem.setPrice(cItem.getMoney());
			oItem.setQuantity(cItem.getQuantity());
			oItem.setOrdernum(ordernum);//��ȡ�ܶ���id��
			oItems.add(oItem);
		}
		// ����������Ͷ����Ĺ�ϵ
		order.setItems(oItems);
		orderService.genOrder(order);
		req.setAttribute("order", order);
		session.removeAttribute("cart");//������ﳵ
		req.getRequestDispatcher("/order.jsp").forward(req, resp);
	}

	// ���ɶ�����
	private String genOrdernum() {
		Date now = new Date();
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String s1 = df.format(now);
		return s1 + System.nanoTime();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
