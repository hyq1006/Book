package cn.xh.web.controller;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.xh.domain.*;
import cn.xh.service.ClientService;
import cn.xh.service.ManagerService;
import cn.xh.service.OrderService;
import cn.xh.service.impl.ClientServiceImpl;
import cn.xh.service.impl.ManagerServiceImpl;
import cn.xh.service.impl.OrderServiceImpl;
import cn.xh.web.formbean.Cart;
import cn.xh.web.formbean.CartItem;

@WebServlet("/client/ClientServlet")
public class ClientServlet extends HttpServlet {
	private ClientService clientService = new ClientServiceImpl();
	private ManagerService managerService = new ManagerServiceImpl();
	private OrderService orderService = new OrderServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");
		String op = req.getParameter("op");// �õ�������������
		if (op != null && !op.equals("")) {
			// ��¼
			if (op.equals("login")) {
				login(req, resp);
			}
			// ע��
			if (op.equals("layout")) {
				layout(req, resp);
			}
			// ע��
			if (op.equals("register")) {
				register(req, resp);
			}
			// ��ѧ�������鼮�б�
			if (op.equals("category")) {
				getCategoryBook(req, resp);
			}

			// ������Ϣ�޸Ĳ���������
			if (op.equals("personInformation")) {
				personInformation(req, resp);
			}
			// �޸�����
			if (op.equals("personPassword")) {
				personPassword(req, resp);
			}
			//��ʾ�û�ȫ����Ϣ
			if(op.equals("person")){
				person(req,resp);
			}
			//�޸��û�ȫ����Ϣ
			if(op.equals("updatePerson")){
				updatePerson(req,resp);
			}
			// ������
			if (op.equals("search")) {
				search(req, resp);
			}
			// ����ҳ��
			if (op.equals("particulars")) {
				particulars(req, resp);
			}
			// ���ӹ��ﳵ
			if (op.equals("addCart")) {
				addCart(req, resp);
			}
			// ɾ�����ﳵ�еĹ�����
			if (op.equals("delItem")) {
				delItem(req, resp);
			}
			// �޸Ĺ���������
			if (op.equals("changeNum")) {
				changeNum(req, resp);
			}
			// �����ղؼ�
			if (op.equals("addfavorite")) {
				addfavorite(req, resp);
			}
			// ��ʾ�ղؼ�
			if (op.equals("showfavorite")) {
				showfavorite(req, resp);
			}
			// ɾ���ղؼ�
			if (op.equals("delFavorite")) {
				delFavorite(req, resp);
			}
			// ��������
			if (op.equals("buyNow")) {
				buNow(req, resp);
			}
			//ɾ���û���Ϣ
			if(op.equals("deletePerson")){
				deletePerson(req,resp);
			}

		}
	}

	private void deletePerson(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String u_id = req.getParameter("u_id");
		User user = new User();
		user.setId(u_id);
		List<Order> orders = orderService.findUserOrders(user);//��ȡ���û��йص����ж���
		for (Order order : orders) {
			deleteOrder(order.getOrdernum());//ɾ���ܶ���
		}
		List<Favorite> favorites = clientService.findFavoriteByUserId(user);//��ȡ���û��йص������ղؼ�
		for (Favorite favorite : favorites) {
			clientService.delFavoriteByUser(u_id);//ɾ���ղؼ�
		}
		if(clientService.deletePerson(u_id)){//���ɾ���û�
			resp.getWriter().write("<div style='text-align: center;margin-top: 260px'><img src='" + req.getContextPath()
					+ "/img/duigou.png'/>ɾ���ɹ���</div>");
		}
	}
	private void deleteOrder(String ordernum) throws IOException {//ɾ��������֮ǰ�Ȼָ�ͼ���棬��ɾ���ܶ���
			List<Orderitem> items = findOrderItems(ordernum);//����ܶ�����������ж�����
			for (Orderitem item : items) {
				Book book = managerService.findBookById(item.getBook().getBook_id());
				int i = book.getBook_kunumber();//���п��
				String kunnumber = String.valueOf(i + item.getQuantity());//���п����϶�����������������ָ�ͼ��Ŀ��
				managerService.editBook(item.getBook().getBook_id(), item.getBook().getBook_name(), item.getBook().getBook_author(), item.getBook().getBook_press(), item.getBook().getBook_desc(), item.getBook().getBook_price(), kunnumber);
				orderService.deleteOrderitems(item.getId());//ɾ��������
			}
			orderService.deleteOrder(ordernum);
		}

//�����ܶ�����ȡ���Ӧ�Ķ�����
	private List<Orderitem> findOrderItems(String ordernum){
		return orderService.finOrdersItemsByNum(ordernum);
	}
	private void updatePerson(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");
		String u_id = req.getParameter("u_id");
		String username = req.getParameter("u_username");
		String password = req.getParameter("u_password");
		String name = req.getParameter("u_name");
		String sex = req.getParameter("u_sex");
		String tel = req.getParameter("u_tel");
		String address = req.getParameter("u_address");
		User user = new User();
		user.setId(u_id);
		user.setUsername(username);
		user.setName(name);
		user.setAddress(address);
		user.setSex(sex);
		user.setTel(tel);
		user.setPassword(password);
		if(clientService.updatePerson(user)){
			resp.getWriter().write("<div style='text-align: center;margin-top: 260px'><img src='" + req.getContextPath()
					+ "/img/duigou.png'/>�޸ĳɹ���</div>");
		}
	}

	private void person(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");
		String u_id = req.getParameter("u_id");
			User user = clientService.findUserById(u_id);
			req.setAttribute("user", user);
			req.getRequestDispatcher("/admin/editPerson.jsp").forward(req, resp);
	}

	private void delFavorite(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");
		String book_id = req.getParameter("book_id");
		clientService.delFavorite(book_id);
		HttpSession session = req.getSession();
		List<Favorite> lists = (List<Favorite>) session.getAttribute("favorite");
		Iterator<Favorite> iterator = lists.iterator();
		while (iterator.hasNext()) {
			Favorite favorite = iterator.next();
			if (book_id.equals(favorite.getBook().getBook_id())) {
				iterator.remove();// ʹ�õ�������ɾ������ɾ��
			}
		}
		resp.sendRedirect(req.getContextPath() + "/favorite.jsp");
	}

	private void showfavorite(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		List<Favorite> favorites = clientService.findFavoriteByUserId(user);
		session.setAttribute("favorite", favorites);
		req.getRequestDispatcher("/favorite.jsp").forward(req, resp);
	}

	private void addfavorite(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		String user_id = user.getId();
		String book_id = req.getParameter("book_id");
		boolean isExit = clientService.findFavorite(user_id, book_id);
		if (isExit == false) {
			clientService.addfavorite(user_id, book_id);
		}
	}

	private void changeNum(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String num = req.getParameter("num");
		String book_id = req.getParameter("book_id");
		// ȡ�����ﳵ
		Cart cart = (Cart) req.getSession().getAttribute("cart");
		CartItem item = cart.getItmes().get(book_id);
		item.setQuantity(Integer.parseInt(num));
		resp.sendRedirect(req.getContextPath() + "/showCart.jsp");

	}

	private void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		HttpSession session = req.getSession();
		User user = clientService.login(username, password);
		if (user.getUsername() != null && user.getUsername() != "") {
			req.setAttribute("message", "��½�ɹ�");
			session.setAttribute("user", user);
			req.getRequestDispatcher("/message.jsp").forward(req, resp);
		} else {
			req.setAttribute("message", "�û�����������������µ�¼");
			req.getRequestDispatcher("/message.jsp").forward(req, resp);
		}
	}

	private void layout(HttpServletRequest req, HttpServletResponse resp) {
		try {
			HttpSession session = req.getSession();
			session.removeAttribute("user");// ��ȡsession���󣬴�session���Ƴ���½��Ϣ
			resp.sendRedirect("/client/ClientServlet?currentPage=1&pageSize=5&op=category");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void register(HttpServletRequest req, HttpServletResponse resp) {
		try {
			String username = req.getParameter("username");
			String password = req.getParameter("password");
			String name = req.getParameter("name");
			String sex = req.getParameter("sex");
			String tel = req.getParameter("tel");
			String address = req.getParameter("address");
			String type = req.getParameter("type");
			System.out.println(type);
			boolean isExist = false;// �ж��Ƿ���ڸ��û�
			if (!username.equals("") && !password.equals("")) {
				isExist = clientService.register(username, password, name, sex, tel, address);
				if (isExist == true) {
					resp.getWriter().write("���û��Ѿ�ע�ᣬ��ֱ��");
					resp.getWriter().write("<a href='" + req.getContextPath() + "/client/ClientServlet?op=category'>��¼</a>");
				}
				if(isExist==false && type.equals("editPerson")){
					resp.getWriter().write("<div style='text-align: center;margin-top: 260px'><img src='" + req.getContextPath()
							+ "/img/duigou.png'/>�����û��ɹ���</div>");
				}
				if(isExist==false && type==null) {
					resp.getWriter().write("ע��ɹ�!");
					resp.getWriter().write("2s��������¼ҳ");
					resp.setHeader("Refresh", "2;URL=" + req.getContextPath() + "/client/ClientServlet?op=category");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void getCategoryBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String currentPage = req.getParameter("currentPage");
		String pageSize = req.getParameter("pageSize");
		String cid = req.getParameter("cid");
		System.out.println(currentPage);
		System.out.println(pageSize);
		Page<Book> book = clientService.seleteBookByPage(Integer.parseInt(pageSize),Integer.parseInt(currentPage),cid);
		//List<Book> books = clientService.getCategoryBook(req.getParameter("cid"));// ��ѧ�������鼮
		req.setAttribute("books", book);//������Ϊ��books,ֵΪbook��request����������
		List<Category> categoryList= managerService.findAllCategory();
		req.setAttribute("categoryList", categoryList);
		req.getRequestDispatcher("/showBook.jsp").forward(req, resp);
	}

	private void personInformation(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException {
		String username = req.getParameter("username");
		String name = req.getParameter("name");
		String sex = req.getParameter("sex");
		String tel = req.getParameter("tel");
		String address = req.getParameter("address");
		clientService.personInformation(username, name, sex, tel, address);
		resp.getWriter().write("<div style='text-align: center;margin-top: 260px'><img src='" + req.getContextPath()
				+ "/img/duigou.png'/>�޸ĳɹ���</div>");
	}

	private void personPassword(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String repassword = req.getParameter("repassword");

		clientService.personPassword(password, username);
		resp.getWriter().write("<div style='text-align: center;margin-top: 260px'><img src='" + req.getContextPath()
				+ "/img/duigou.png'/>�޸ĳɹ���</div>");
	}

	private void search(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String search = req.getParameter("search");
		List<Book> searchmessage = clientService.search(search);
		req.setAttribute("books", searchmessage);
		req.getRequestDispatcher("/showBook.jsp").forward(req, resp);
	}

	private void particulars(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String book_id = req.getParameter("book_id");
		Book book = findBookById(book_id);
		req.setAttribute("book", book);
		req.getRequestDispatcher("/particulars.jsp").forward(req, resp);
	}

	// ͨ���鼮id�ҵ��鼮��Ϣ
	private Book findBookById(String book_id) {
		Book book = clientService.findBookById(book_id);
		return book;
	}

	private void addCart(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String book_id = req.getParameter("book_id");
		Book book = findBookById(book_id);
		HttpSession session = req.getSession();
		Cart cart = (Cart) session.getAttribute("cart");//��ȡδ���Ӹ��鼮֮ǰ�Ĺ��ﳵ��Ϣ
		if (cart == null) {
			cart = new Cart();
			session.setAttribute("cart", cart);//��������cart,����δ���Ӹ��鼮֮ǰ�Ĺ��ﳵ��Ϣ�ӽ�ȥ
		}
		cart.addBook(book);//���������ӵ��鼮����cart��book����
	}

	private void delItem(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String book_id = req.getParameter("book_id");
		Cart cart = (Cart) req.getSession().getAttribute("cart");
		cart.getItmes().remove(book_id);
		resp.sendRedirect(req.getContextPath() + "/showCart.jsp");
	}

	private void buNow(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String book_id = req.getParameter("book_id");
		Book book = findBookById(book_id);
		HttpSession session = req.getSession();
		Cart cart = new Cart();
		session.setAttribute("buyNowBook", cart);
		cart.addBook(book);
		Cart book1 = (Cart)session.getAttribute("buyNowBook");
		Collection<CartItem> values = cart.getItmes().values();
		System.out.println(book1);
		resp.sendRedirect(req.getContextPath() + "/buyNow.jsp");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
